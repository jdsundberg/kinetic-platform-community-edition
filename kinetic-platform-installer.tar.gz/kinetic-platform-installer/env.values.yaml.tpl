# =============================================================================
# Kinetic Platform - Installer Values Template
# =============================================================================
#
# This file is processed by install.sh — do not edit placeholders manually.
#
# Pre-configured for:
#   - In-cluster Cassandra
#   - In-cluster PostgreSQL
#   - 1-node Rabbit
#   - Single replica per service, no HPA
#
# =============================================================================

# ===== Required: Hostname =====
essentials:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  nfsClusterServer: "__NFS_SERVER__"
  nfsClusterPath: "__NFS_PATH__"
  platform:
    system_username: "__SYSTEM_USERNAME__"
    system_password: "__SYSTEM_PASSWORD__"
    encryption_key: "__ENCRYPTION_KEY__"
    secrets:
      trusted: "__TRUSTED_SECRET__"
      active: "__ACTIVE_SECRET__"

# ===== Required: Init =====
init:
  namespace: kinetic
  deployment: kinops

# ===== Cassandra (In-Cluster, sized for 8-core/32GB) =====
cassandra:
  enabled: true
  clientEncryption:
    pemSecret: "internal-tls-secret"
  resources:
    limits:
      cpu: 2000m
      memory: 6Gi
    requests:
      cpu: 1000m
      memory: 4Gi
  config:
    maxHeapSize: "2G"
    heapNewSize: "400M"

cassandra-adapter-secret-init:
  namespace: kinetic
  agent:
    keyspace: "kinetic_agent"
  core:
    keyspace: "kinetic_core"
  cassandra:
    properties:
      contactpoints: "kinetic-platform-cassandra.kinetic.svc.cluster.local"
      datacenter: "datacenter1"
      username: "cassandra"
      password: "cassandra"
      truststore_password: "__CASSANDRA_TRUSTSTORE_PASSWORD__"
      pemSecretName: "internal-tls-secret"

# ===== Elasticsearch =====
# MUST be aligned with the ES deployment mode:
#   - Bundled ES (single-node, deployed by this chart):
#       elasticsearch.enabled: true
#       elasticsearch-adapter-secret-init.useGeneratedPassword: true
#     The post-install Job reads the auto-generated `elastic` password from
#     the `elasticsearch-master-credentials` Secret and patches it into the
#     adapter Secret. The `password` value below is ignored.
#
#   - External/BYO Elasticsearch:
#       elasticsearch.enabled: false
#       elasticsearch-adapter-secret-init.useGeneratedPassword: false
#     The operator supplies `username` and `password` directly below; the
#     adapter Secret carries those values verbatim.
#
# Mismatched settings (e.g. bundled ES + useGeneratedPassword=false) result
# in HTTP 401 between loghub/logstash and Elasticsearch. The standalone
# installer's `install.sh` derives both fields from the same prompt.
elasticsearch-adapter-secret-init:
  enabled: __ELASTICSEARCH_ENABLED__
  namespace: kinetic
  useGeneratedPassword: __USE_GENERATED_PASSWORD__
  elasticsearch:
    env:
      username: "__ES_USERNAME__"
      password: "__ES_PASSWORD__"
      indexBasePattern: kinetic
      indexSearchPattern: "kinetic-*"
    properties:
      host: "__ES_HOST__"
      port: "__ES_PORT__"
      scheme: __ES_SCHEME__
    cert: "__ES_CERT__"

elasticsearch:
  enabled: __ES_IN_CLUSTER__

# ===== TLS Certificate =====
platform-certificate-init:
  namespace: kinetic
  ssl:
    ingress:
      tls_cert: |
__TLS_CERT__
      tls_key: |
__TLS_KEY__
      tls_chain: |
__TLS_CHAIN__

# ===== NFS Provisioner =====
nfs-provisioner:
  nfs:
    server: "__NFS_SERVER__"
    path: "__NFS_PATH__"

# ===== CoreDNS =====
coredns:
  enabled: true
  hostname: "__HOSTNAME__"
  namespace: kinetic
  ingressProvider: "__INGRESS_PROVIDER__"

# ===== Ingress Provider =====
global:
  ingress:
    provider: "__INGRESS_PROVIDER__"
    className: "__INGRESS_CLASS__"

ingress:
  enabled: __INGRESS_NGINX_ENABLED__
  namespace: kinetic
  replicas: 1
  ports:
    http:
      nodePort: __HTTP_NODEPORT__
__NGINX_HTTP_HOSTPORT__
    https:
      nodePort: __HTTPS_NODEPORT__
__NGINX_HTTPS_HOSTPORT__

traefik:
  enabled: __TRAEFIK_ENABLED__
  ingressClass:
    name: "traefik"
  logs:
    general:
      level: "INFO"
  additionalArguments:
    - "--serversTransport.insecureSkipVerify=true"
  service:
    type: NodePort
  ports:
    web:
      nodePort: __HTTP_NODEPORT__
__TRAEFIK_HTTP_HOSTPORT__
    websecure:
      nodePort: __HTTPS_NODEPORT__
__TRAEFIK_HTTPS_HOSTPORT__

# ===== Platform Services (1 replica each, no HPA) =====
core:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  replicas: 1
  hpa: false

agent:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  replicas: 1
  hpa: false

system-coordinator:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  nfsClusterServer: "__NFS_SERVER__"
  nfsClusterPath: "__NFS_PATH__"
  replicas: 1
  hpa: false

system-console:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  replicas: 1
  hpa: false

space-console:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  replicas: 1
  hpa: false

oas-console:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  replicas: 1
  hpa: false

loghub:
  enabled: __LOGHUB_ENABLED__
  hostname: "__HOSTNAME__"
  namespace: kinetic
  replicas: 1
  hpa: false

indexer:
  hostname: "__HOSTNAME__"
  namespace: kinetic
  replicas: 1
  hpa: false

bundles:
  namespace: kinetic
  replicas: 1
  hpa: false

log-collector:
  enabled: __LOG_COLLECTOR_ENABLED__
  namespace: kinetic

system-initialization:
  hostname: "__HOSTNAME__"
  namespace: kinetic

# ===== In-Cluster PostgreSQL =====
postgresql:
  enabled: true
  tls:
    enabled: true
    existingSecret: "internal-tls-secret"
  backup:
    enabled: true
    schedule: "0 2 * * *"
    retentionDays: 7
    storageProvider: nfs
    nfs:
      existingClaim: "shared-pv-claim"
      subPath: "postgresql-backups"

# ===== Rabbit (1 node) =====
rabbit-cluster:
  replicas: 1
