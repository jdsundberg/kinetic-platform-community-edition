#!/usr/bin/env bash
# =============================================================================
# Kinetic Platform — Local Access Setup
# =============================================================================
# Sets up a local reverse proxy (Caddy) so you can access the platform
# from your browser. Run this on your Mac or Linux workstation.
#
# Usage: ./local-access.sh
# =============================================================================

set -euo pipefail

# ===== Colors =====
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; }
header()  { echo -e "\n${BOLD}${CYAN}=== $* ===${NC}\n"; }

die() { error "$*"; exit 1; }

# =============================================================================
# Step 1: Prompt for Connection Info
# =============================================================================
prompt_connection_info() {
    header "Connection Setup"

    echo -e "${BOLD}Enter the server IP address${NC}"
    echo "  (The IP printed at the end of install.sh)"
    read -rp "> " SERVER_IP
    [[ -n "$SERVER_IP" ]] || die "Server IP is required"

    echo ""
    echo -e "${BOLD}Enter the domain name${NC}"
    echo "  (Same domain used during server install)"
    read -rp "> " DOMAIN
    [[ -n "$DOMAIN" ]] || die "Domain is required"

    echo ""
    echo -e "${BOLD}Select ingress provider:${NC}"
    echo "  1) traefik (default)"
    echo "  2) nginx"
    read -rp "Choice [1]: " ingress_choice
    ingress_choice="${ingress_choice:-1}"
    case "$ingress_choice" in
        1) INGRESS_PROVIDER="traefik"; NODEPORT=31443 ;;
        2) INGRESS_PROVIDER="nginx"; NODEPORT=30443 ;;
        *) die "Invalid choice" ;;
    esac

    info "Server:   ${SERVER_IP}:${NODEPORT}"
    info "Domain:   ${DOMAIN}"
    info "Ingress:  ${INGRESS_PROVIDER}"
}

# =============================================================================
# Step 2: Check Ports
# =============================================================================
check_ports() {
    header "Checking Ports"

    CADDY_HTTP_PORT=80
    CADDY_HTTPS_PORT=443

    for port in 80 443; do
        local pid
        pid=$(lsof -ti ":${port}" 2>/dev/null || true)
        if [[ -n "$pid" ]]; then
            local proc
            proc=$(ps -p "$pid" -o comm= 2>/dev/null || echo "unknown")
            warn "Port ${port} is in use by ${proc} (PID ${pid})"
            echo -e "  ${BOLD}Options:${NC}"
            echo "    1) Kill the process"
            echo "    2) Use alternate ports (8080/8443)"
            echo "    3) Abort"
            read -rp "  Choice [2]: " port_choice
            port_choice="${port_choice:-2}"
            case "$port_choice" in
                1)
                    kill "$pid" 2>/dev/null && success "Killed PID $pid" || warn "Could not kill PID $pid — try running with sudo"
                    ;;
                2)
                    CADDY_HTTP_PORT=8080
                    CADDY_HTTPS_PORT=8443
                    warn "Using alternate ports: HTTP=${CADDY_HTTP_PORT}, HTTPS=${CADDY_HTTPS_PORT}"
                    break
                    ;;
                3) exit 0 ;;
                *) die "Invalid choice" ;;
            esac
        fi
    done

    success "Ports ${CADDY_HTTP_PORT}/${CADDY_HTTPS_PORT} available"
}

# =============================================================================
# Step 3: Update /etc/hosts
# =============================================================================
update_hosts() {
    header "Updating /etc/hosts"

    local hosts_entry="127.0.0.1 ${DOMAIN}"

    if grep -qF "$DOMAIN" /etc/hosts 2>/dev/null; then
        info "/etc/hosts already contains an entry for ${DOMAIN}"
    else
        info "Adding: ${hosts_entry}"
        echo "$hosts_entry" | sudo tee -a /etc/hosts > /dev/null
        success "Added ${DOMAIN} to /etc/hosts"
    fi
}

# =============================================================================
# Step 4: Install Caddy
# =============================================================================
install_caddy() {
    header "Installing Caddy"

    if command -v caddy &>/dev/null; then
        info "Caddy already installed: $(caddy version 2>/dev/null || echo 'unknown')"
        return
    fi

    local os
    os="$(uname -s)"

    case "$os" in
        Darwin)
            if command -v brew &>/dev/null; then
                info "Installing via Homebrew..."
                brew install caddy
            else
                die "Homebrew not found. Install Caddy manually: https://caddyserver.com/docs/install"
            fi
            ;;
        Linux)
            info "Downloading Caddy..."
            local arch
            arch="$(uname -m)"
            case "$arch" in
                x86_64)  arch="amd64" ;;
                aarch64) arch="arm64" ;;
                *) die "Unsupported architecture: $arch" ;;
            esac
            curl -sSL "https://caddyserver.com/api/download?os=linux&arch=${arch}" -o /tmp/caddy
            chmod +x /tmp/caddy
            sudo mv /tmp/caddy /usr/local/bin/caddy
            ;;
        *)
            die "Unsupported OS: $os. Install Caddy manually: https://caddyserver.com/docs/install"
            ;;
    esac

    success "Caddy installed"
}

# =============================================================================
# Step 5: Create Caddyfile
# =============================================================================
create_caddyfile() {
    header "Creating Caddyfile"

    CADDYFILE="${SCRIPT_DIR:-$(pwd)}/Caddyfile"

    # Build port suffix for listen addresses
    local http_addr=""
    local https_addr=""
    if [[ "$CADDY_HTTPS_PORT" != "443" ]]; then
        https_addr=":${CADDY_HTTPS_PORT}"
    fi
    if [[ "$CADDY_HTTP_PORT" != "80" ]]; then
        http_addr=":${CADDY_HTTP_PORT}"
    fi

    cat > "$CADDYFILE" <<EOF
{
    local_certs
    http_port  ${CADDY_HTTP_PORT}
    https_port ${CADDY_HTTPS_PORT}
}

${DOMAIN}${https_addr} {
    reverse_proxy https://${SERVER_IP}:${NODEPORT} {
        transport http {
            tls_insecure_skip_verify
        }
        header_up Host ${DOMAIN}:443
        header_up X-Forwarded-URL https://${DOMAIN}:443{uri}
    }
}
EOF

    success "Caddyfile created: ${CADDYFILE}"
    echo ""
    cat "$CADDYFILE"
}

# =============================================================================
# Step 6: Start Caddy
# =============================================================================
start_caddy() {
    header "Starting Caddy"

    # Stop any existing Caddy
    caddy stop 2>/dev/null || true

    info "Starting Caddy reverse proxy..."
    info "Caddyfile: ${CADDYFILE}"
    echo ""

    local url
    if [[ "$CADDY_HTTPS_PORT" == "443" ]]; then
        url="https://${DOMAIN}/app/console/"
    else
        url="https://${DOMAIN}:${CADDY_HTTPS_PORT}/app/console/"
    fi

    echo -e "${BOLD}${GREEN}Ready! Open in your browser:${NC}"
    echo ""
    echo -e "  ${BOLD}${url}${NC}"
    echo ""
    echo -e "${YELLOW}Note:${NC} Your browser will warn about the self-signed certificate."
    echo "  Click 'Advanced' → 'Proceed' to continue."
    echo ""
    echo "Press Ctrl+C to stop the proxy."
    echo ""

    # Run Caddy in foreground so Ctrl+C stops it
    sudo caddy run --config "$CADDYFILE" --adapter caddyfile
}

# =============================================================================
# Main
# =============================================================================
main() {
    echo -e "${BOLD}${CYAN}"
    echo "  ╔════════════════════════════════════════╗"
    echo "  ║   Kinetic Platform — Local Access      ║"
    echo "  ╚════════════════════════════════════════╝"
    echo -e "${NC}"

    # Use script's directory as default SCRIPT_DIR
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    prompt_connection_info
    check_ports
    update_hosts
    install_caddy
    create_caddyfile
    start_caddy
}

main "$@"
