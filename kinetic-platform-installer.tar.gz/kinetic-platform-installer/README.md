# Kinetic Platform Installer

Self-contained installer for deploying the Kinetic Platform on a fresh Ubuntu server.

## What's in the Box

| File | Purpose |
|---|---|
| `install.sh` | Server-side installer — sets up k0s, NFS, Helm, and deploys the platform |
| `local-access.sh` | Local machine script — Caddy reverse proxy + /etc/hosts for browser access |
| `env.values.yaml.tpl` | Helm values template (placeholders replaced by install.sh) |
| `kinetic-platform-*.tgz` | Pre-packaged Helm chart |
| `README.md` | This file |

## Prerequisites

- **Server:** Ubuntu 22.04+ with root/sudo SSH access
- **Internet:** Required for downloading k0s, Helm, and container images
- **Resources:** Minimum 8 CPU, 32 GB RAM, 100 GB disk recommended
- **Local machine:** macOS or Linux (for local-access.sh)

## Server Install

1. Copy the installer package to your server:
   ```bash
   scp kinetic-platform-installer.tar.gz user@server:~/
   ```

2. SSH into the server and extract:
   ```bash
   ssh user@server
   tar xzf kinetic-platform-installer.tar.gz
   cd kinetic-platform-installer
   ```

3. Run the installer as root:
   ```bash
   # Interactive — prompts for domain, ingress provider, etc.
   sudo ./install.sh

   # Starter mode — non-interactive with sensible defaults
   sudo ./install.sh --starter

   # Starter mode with custom domain
   sudo ./install.sh --starter --domain kinetic.example.com

   # Starter mode with custom domain and custom admin password 
   sudo ./install.sh --starter --domain kinetic.example.com --password s3cr3t


   # Starter mode with explicit opt-out of Elasticsearch
   sudo ./install.sh --starter --without-elasticsearch
   ```

4. **Interactive mode** prompts for:
   - **Domain** — e.g., `kinetic.example.com` (all services use `*.domain`)
   - **Ingress provider** — traefik (recommended) or nginx
   - **Elasticsearch** — enables search/indexing plus loghub and log-collector

   **Starter mode** (`--starter`) skips all prompts and uses: traefik, in-cluster Elasticsearch, domain `kinetic.local` (override with `--domain`). Add `--without-elasticsearch` to disable Elasticsearch and skip loghub/log-collector. For an external Elasticsearch, use interactive mode.

5. Wait for installation to complete (~10-15 minutes). Credentials are printed at the end.

## Local Access

On your Mac or Linux workstation:

```bash
./local-access.sh
```

Follow the prompts to enter the server IP, domain, and ingress provider. The script:
- Adds the domain to `/etc/hosts` (pointing to 127.0.0.1)
- Installs Caddy if needed (via Homebrew on macOS)
- Creates a reverse proxy from your machine to the server's NodePort
- Starts Caddy in the foreground (Ctrl+C to stop)

Then open: `https://<domain>/app/console/`

Your browser will warn about a self-signed certificate — click through to proceed.

## What Gets Installed (Server)

- **k0s** — Single-node Kubernetes cluster
- **NFS server** — Shared storage at `/srv/nfs/kinetic`
- **Helm 3** — Kubernetes package manager
- **Kinetic Platform** including:
  - Cassandra (in-cluster, single node)
  - PostgreSQL (in-cluster)
  - RabbitMQ (single node)
  - Core, Agent, System Coordinator
  - System Console, Space Console, OAS Console
  - Indexer, Bundles
  - Loghub + Log Collector (if Elasticsearch enabled)

All services run with **1 replica** and no HPA. Scale up manually after install if needed.

## Ports

| Provider | HTTP NodePort | HTTPS NodePort |
|---|---|---|
| traefik | 31080 | 31443 |
| nginx | 30080 | 30443 |

## Credentials

Printed at the end of `install.sh` and stored in `env.values.yaml`:
- **System Username** — `admin`
- **System Password** — randomly generated
- **Encryption Key** — in `essentials.platform.encryption_key`

## Uninstall

```bash
# Remove the Helm release
sudo helm uninstall kinetic-platform -n kinetic

# Remove NFS export
sudo rm -rf /srv/nfs/kinetic
sudo sed -i '/srv\/nfs\/kinetic/d' /etc/exports
sudo exportfs -ra

# Stop and remove k0s
sudo k0s stop
sudo k0s reset
```

## Troubleshooting

**Pods stuck in Pending/CrashLoopBackOff:**
```bash
sudo k0s kubectl get pods -n kinetic
sudo k0s kubectl describe pod <pod-name> -n kinetic
sudo k0s kubectl logs <pod-name> -n kinetic
```

**NFS mount failures:**
- Ensure NFS server is running: `systemctl status nfs-kernel-server`
- Check exports: `exportfs -v`
- Verify node IP matches `nfsClusterServer` in `env.values.yaml`

**Certificate issues:**
- Certs are in the `certs/` directory created by install.sh
- The platform-certificate-init job may skip if an `ingress` secret already exists
- Delete and reinstall if certs need to change: `kubectl delete secret ingress -n kinetic`

**CoreDNS not resolving the domain inside the cluster:**
- Verify configmap is Helm-managed: `kubectl get configmap coredns -n kube-system -o yaml`
- Restart CoreDNS: `kubectl rollout restart deployment coredns -n kube-system`

**504 Gateway Timeout (traefik):**
- Network policies may be blocking traffic — check: `kubectl get networkpolicy -n kinetic`
- Delete all policies if needed: `kubectl delete networkpolicy --all -n kinetic`

**local-access.sh — ports in use:**
- The script offers to use alternate ports 8080/8443
- Or kill the blocking process manually: `lsof -ti :443 | xargs kill`
