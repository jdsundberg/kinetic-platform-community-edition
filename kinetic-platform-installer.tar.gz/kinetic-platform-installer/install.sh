#!/usr/bin/env bash
# =============================================================================
# Kinetic Platform Installer
# =============================================================================
# Installs the Kinetic Platform on a fresh Linux (compatible with Ubuntu or Redhat)server with:
#   - k0s (single-node Kubernetes)
#   - NFS server (shared storage)
#   - Helm 3 (package manager)
#   - Self-signed TLS certificates
#   - Kinetic Platform Helm chart
#
# Usage: sudo ./install.sh [--starter] [--domain DOMAIN] [--password PASSWORD] [--without-elasticsearch]
# =============================================================================

set -euo pipefail

# ===== Mode =====
DEMO_MODE="false"
CUSTOM_DOMAIN=""
CUSTOM_PASSWORD=""
WITH_ELASTICSEARCH="true"
ELASTICSEARCH_OVERRIDE="false"
while [[ $# -gt 0 ]]; do
    case $1 in
        --starter) DEMO_MODE="true"; shift ;;
        --domain) CUSTOM_DOMAIN="$2"; shift 2 ;;
        --password) CUSTOM_PASSWORD="$2"; shift 2 ;;
        --without-elasticsearch) WITH_ELASTICSEARCH="false"; ELASTICSEARCH_OVERRIDE="true"; shift ;;
        *)        shift ;;
    esac
done

if [[ "$ELASTICSEARCH_OVERRIDE" == "true" && "$DEMO_MODE" != "true" ]]; then
    echo "[ERROR] Elasticsearch flags only apply to --starter mode; interactive mode prompts for Elasticsearch." >&2
    exit 1
fi

# ===== Constants =====
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHART_FILE="$(ls "${SCRIPT_DIR}"/kinetic-platform-*.tgz 2>/dev/null | head -1)"
TPL_FILE="${SCRIPT_DIR}/env.values.yaml.tpl"
VALUES_FILE="${SCRIPT_DIR}/env.values.yaml"
NFS_PATH="/srv/nfs/kinetic"
NAMESPACE="kinetic"
RELEASE_NAME="kinetic-platform"
K0S_VERSION="${K0S_VERSION:-v1.34.4+k0s.0}"
HELM_VERSION="${HELM_VERSION:-v3.16.4}"

# ===== Colors =====
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ===== Helpers =====
info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; }
header()  { echo -e "\n${BOLD}${CYAN}=== $* ===${NC}\n"; }

die() {
    error "$*"
    exit 1
}

trap 'error "Install failed at line $LINENO. Check output above for details."' ERR

spinner() {
    local pid=$1
    local msg=$2
    local chars='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    local i=0
    while kill -0 "$pid" 2>/dev/null; do
        printf "\r${BLUE}[%s]${NC} %s" "${chars:i++%${#chars}:1}" "$msg"
        sleep 0.1
    done
    printf "\r"
}

wait_with_spinner() {
    local msg="$1"
    shift
    "$@" &
    local pid=$!
    spinner "$pid" "$msg"
    wait "$pid"
}

# =============================================================================
# Step 1: Validate Prerequisites
# =============================================================================
validate_prerequisites() {
    header "Validating Prerequisites"

    # Must be root or sudo
    if [[ $EUID -ne 0 ]]; then
        die "This script must be run as root (use sudo ./install.sh)"
    fi

    # Check Ubuntu
    # disabling this check -- should work for other distros too, but untested 
    # have tested ubuntu and Redhat compatible distros, but not all distros.
    # JDS 
    # if ! grep -qi ubuntu /etc/os-release 2>/dev/null; then
    #     warn "This script is designed for Ubuntu. Other distros may work but are untested."
    #     read -rp "Continue anyway? [y/N] " yn
    #     [[ "$yn" =~ ^[Yy] ]] || exit 1
    # fi

    # Check required files
    [[ -f "$TPL_FILE" ]] || die "Missing values template: $TPL_FILE"
    [[ -f "$CHART_FILE" ]] || die "Missing Helm chart: $CHART_FILE"

    # Check internet connectivity
    if ! curl -sf --max-time 5 https://github.com > /dev/null 2>&1; then
        AIRGAP=true
        warn "No internet connectivity — running in air-gap mode"
        # Verify pre-staged binaries exist
        local bindir="${SCRIPT_DIR}/binaries"
        if [[ ! -d "$bindir" ]]; then
            die "Air-gap mode requires pre-staged binaries in ${bindir}/. Build with: bash build.sh --airgap"
        fi
    else
        AIRGAP=false
    fi

    success "Prerequisites validated"
}

# =============================================================================
# Step 2a: Demo Defaults (non-interactive)
# =============================================================================
demo_defaults() {
    header "Starter Mode"

    DOMAIN="${CUSTOM_DOMAIN:-kinetic.local}"
    INGRESS_PROVIDER="traefik"
    INGRESS_CLASS="traefik"
    INGRESS_NGINX_ENABLED="false"
    TRAEFIK_ENABLED="true"
    USE_HOST_PORT="true"
    HTTP_NODEPORT=30080
    HTTPS_NODEPORT=30443
    if [[ "$WITH_ELASTICSEARCH" == "true" ]]; then
        ELASTICSEARCH_ENABLED="true"
        ES_IN_CLUSTER="true"
        LOGHUB_ENABLED="true"
        LOG_COLLECTOR_ENABLED="true"
        ES_HOST="elasticsearch-master.kinetic.svc.cluster.local"
        ES_PORT="9200"
        ES_SCHEME="https"
        ES_USERNAME="elastic"
        # Bundled ES auto-generates its `elastic` user password into the
        # elasticsearch-master-credentials Secret. The secret-init Job picks
        # it up at install time when useGeneratedPassword=true. The literal
        # password value here is unused — the chart hardcodes "placeholder".
        ES_PASSWORD="placeholder"
        USE_GENERATED_PASSWORD="true"
        ES_CERT=""
    else
        ELASTICSEARCH_ENABLED="false"
        ES_IN_CLUSTER="false"
        LOGHUB_ENABLED="false"
        LOG_COLLECTOR_ENABLED="false"
        ES_HOST=""
        ES_PORT="9200"
        ES_SCHEME="https"
        ES_USERNAME=""
        ES_PASSWORD=""
        USE_GENERATED_PASSWORD="false"
        ES_CERT=""
    fi

    # Check if ports 80/443 are available, fall back to NodePort
    if ss -tlnp 2>/dev/null | grep -q ':80 ' || ss -tlnp 2>/dev/null | grep -q ':443 '; then
        USE_HOST_PORT="false"
        info "Ports 80/443 in use, falling back to NodePort (30080/30443)"
    fi

    # Detect node IP
    NFS_SERVER=$(ip -4 route get 8.8.8.8 | awk '{print $7; exit}')
    [[ -n "$NFS_SERVER" ]] || die "Could not detect node IP address"

    # Detect public IP
    PUBLIC_IP=$(curl -sf --max-time 3 http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || \
                curl -sf --max-time 3 https://ifconfig.me 2>/dev/null || \
                echo "")
    if [[ "$PUBLIC_IP" == "$NFS_SERVER" ]]; then
        PUBLIC_IP=""
    fi

    # Generate secrets
    SYSTEM_USERNAME="admin"
    SYSTEM_PASSWORD="${CUSTOM_PASSWORD:-$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)}"
    ENCRYPTION_KEY="$(openssl rand -hex 16)"
    SIGNING_SECRET="$(openssl rand -hex 16)"
    TRUSTED_SECRET="$SIGNING_SECRET"
    ACTIVE_SECRET="$SIGNING_SECRET"
    CASSANDRA_TRUSTSTORE_PASSWORD="$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)"

    info "Domain:            $DOMAIN"
    info "Ingress:           $INGRESS_PROVIDER"
    if [[ "$USE_HOST_PORT" == "true" ]]; then
        info "Ports:             80/443 (hostPort)"
    else
        info "Ports:             30080/30443 (NodePort)"
    fi
    if [[ "$ELASTICSEARCH_ENABLED" == "true" ]]; then
        info "Elasticsearch:     in-cluster"
    else
        info "Elasticsearch:     disabled"
    fi
    info "NFS Server IP:     $NFS_SERVER"
    info "System Username:   $SYSTEM_USERNAME"
    echo ""
    success "Demo defaults applied"
}

# =============================================================================
# Step 2: Prompt User
# =============================================================================
prompt_user() {
    header "Configuration"

    # Domain
    echo -e "${BOLD}Enter the domain name for the platform${NC}"
    echo "  Example: kinetic.example.com"
    echo "  This will be used for all platform services (*.domain)"
    read -rp "> " DOMAIN
    [[ -n "$DOMAIN" ]] || die "Domain is required"

    # Ingress provider
    echo ""
    echo -e "${BOLD}Select ingress provider:${NC}"
    echo "  1) traefik (recommended)"
    echo "  2) nginx"
    read -rp "Choice [1]: " ingress_choice
    ingress_choice="${ingress_choice:-1}"
    case "$ingress_choice" in
        1) INGRESS_PROVIDER="traefik" ;;
        2) INGRESS_PROVIDER="nginx" ;;
        *) die "Invalid choice" ;;
    esac

    # Elasticsearch
    echo ""
    echo -e "${BOLD}Elasticsearch setup:${NC}"
    echo "  1) None — skip Elasticsearch"
    echo "  2) In-cluster — deploy Elasticsearch inside Kubernetes (default)"
    echo "  3) External — connect to your own Elasticsearch cluster"
    read -rp "Choice [2]: " es_choice
    es_choice="${es_choice:-2}"
    case "$es_choice" in
        1)
            ELASTICSEARCH_ENABLED="false"
            ES_IN_CLUSTER="false"
            LOGHUB_ENABLED="false"
            LOG_COLLECTOR_ENABLED="false"
            ES_HOST=""
            ES_PORT="9200"
            ES_SCHEME="https"
            ES_USERNAME=""
            ES_PASSWORD=""
            USE_GENERATED_PASSWORD="false"
            ES_CERT=""
            ;;
        2)
            ELASTICSEARCH_ENABLED="true"
            ES_IN_CLUSTER="true"
            LOGHUB_ENABLED="true"
            LOG_COLLECTOR_ENABLED="true"
            ES_HOST="elasticsearch-master.kinetic.svc.cluster.local"
            ES_PORT="9200"
            ES_SCHEME="https"
            ES_USERNAME="elastic"
            # Bundled ES — secret-init reads real password from
            # elasticsearch-master-credentials at install time.
            ES_PASSWORD="placeholder"
            USE_GENERATED_PASSWORD="true"
            ES_CERT=""
            info "In-cluster Elasticsearch will be deployed (single node)"
            ;;
        3)
            ELASTICSEARCH_ENABLED="true"
            ES_IN_CLUSTER="false"
            LOGHUB_ENABLED="true"
            LOG_COLLECTOR_ENABLED="true"
            echo ""
            echo -e "${BOLD}External Elasticsearch connection details:${NC}"
            read -rp "  Host (e.g., elasticsearch.mydomain.com): " ES_HOST
            [[ -n "$ES_HOST" ]] || die "Elasticsearch host is required"
            read -rp "  Port [9200]: " ES_PORT
            ES_PORT="${ES_PORT:-9200}"
            read -rp "  Scheme (https/http) [https]: " ES_SCHEME
            ES_SCHEME="${ES_SCHEME:-https}"
            read -rp "  Username: " ES_USERNAME
            read -rsp "  Password: " ES_PASSWORD
            echo ""
            # External ES — operator provided the credentials, do not try to
            # read from the bundled elasticsearch-master-credentials Secret
            # (it won't exist).
            USE_GENERATED_PASSWORD="false"
            ES_CERT=""
            if [[ "$ES_SCHEME" == "https" ]]; then
                echo "  CA certificate PEM file (leave blank if using a public CA):"
                read -rp "  Path to PEM file: " es_cert_path
                if [[ -n "$es_cert_path" && -f "$es_cert_path" ]]; then
                    ES_CERT=$(base64 -w0 "$es_cert_path" 2>/dev/null || base64 "$es_cert_path")
                fi
            fi
            ;;
        *)
            die "Invalid choice"
            ;;
    esac

    # Derived values
    if [[ "$INGRESS_PROVIDER" == "traefik" ]]; then
        INGRESS_CLASS="traefik"
        INGRESS_NGINX_ENABLED="false"
        TRAEFIK_ENABLED="true"
    else
        INGRESS_CLASS="nginx"
        INGRESS_NGINX_ENABLED="true"
        TRAEFIK_ENABLED="false"
    fi

    # Port configuration — default to NodePort range
    HTTP_NODEPORT=30080
    HTTPS_NODEPORT=30443
    USE_HOST_PORT="false"

    # Check if ports 80 and 443 are available on the host
    echo ""
    local port_80_free="true"
    local port_443_free="true"
    if ss -tlnp 2>/dev/null | grep -q ':80 ' || netstat -tlnp 2>/dev/null | grep -q ':80 '; then
        port_80_free="false"
    fi
    if ss -tlnp 2>/dev/null | grep -q ':443 ' || netstat -tlnp 2>/dev/null | grep -q ':443 '; then
        port_443_free="false"
    fi

    if [[ "$port_80_free" == "true" && "$port_443_free" == "true" ]]; then
        echo -e "${BOLD}Ports 80 and 443 are available on this host.${NC}"
        echo "  1) Use ports 80/443 directly (no proxy needed on your local machine)"
        echo "  2) Use NodePort range 30080/30443 (default)"
        read -rp "Choice [1]: " port_choice
        port_choice="${port_choice:-1}"
        case "$port_choice" in
            1) USE_HOST_PORT="true" ;;
            2) USE_HOST_PORT="false" ;;
            *) die "Invalid choice" ;;
        esac
    else
        if [[ "$port_80_free" == "false" ]]; then
            warn "Port 80 is already in use on this host"
        fi
        if [[ "$port_443_free" == "false" ]]; then
            warn "Port 443 is already in use on this host"
        fi
        info "Using NodePort range (30080/30443)"
    fi

    # Detect node IP (not loopback — pods can't mount NFS from their own loopback)
    NFS_SERVER=$(ip -4 route get 8.8.8.8 | awk '{print $7; exit}')
    [[ -n "$NFS_SERVER" ]] || die "Could not detect node IP address"

    # Detect public IP (if available — e.g., EC2 instances)
    PUBLIC_IP=$(curl -sf --max-time 3 http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || \
                curl -sf --max-time 3 https://ifconfig.me 2>/dev/null || \
                echo "")
    # Only keep if it differs from the private IP
    if [[ "$PUBLIC_IP" == "$NFS_SERVER" ]]; then
        PUBLIC_IP=""
    fi

    # Generate secrets
    SYSTEM_USERNAME="admin"
    SYSTEM_PASSWORD="${CUSTOM_PASSWORD:-$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)}"
    ENCRYPTION_KEY="$(openssl rand -hex 16)"
    SIGNING_SECRET="$(openssl rand -hex 16)"
    TRUSTED_SECRET="$SIGNING_SECRET"
    ACTIVE_SECRET="$SIGNING_SECRET"
    CASSANDRA_TRUSTSTORE_PASSWORD="$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)"

    echo ""
    info "Domain:            $DOMAIN"
    info "Ingress:           $INGRESS_PROVIDER ($INGRESS_CLASS)"
    if [[ "$USE_HOST_PORT" == "true" ]]; then
        info "Ports:             80/443 (hostPort)"
    else
        info "Ports:             30080/30443 (NodePort)"
    fi
    if [[ "$ES_IN_CLUSTER" == "true" ]]; then
        info "Elasticsearch:     in-cluster"
    elif [[ "$ELASTICSEARCH_ENABLED" == "true" ]]; then
        info "Elasticsearch:     external ($ES_HOST:$ES_PORT)"
    else
        info "Elasticsearch:     disabled"
    fi
    info "NFS Server IP:     $NFS_SERVER"
    info "System Username:   $SYSTEM_USERNAME"
    echo ""
    read -rp "Proceed with installation? [Y/n] " proceed
    [[ ! "$proceed" =~ ^[Nn] ]] || exit 0
}

# =============================================================================
# Step 3: Install NFS Server
# =============================================================================
install_nfs() {
    header "Installing NFS Server"

    if command -v apt-get >/dev/null; then
        apt-get update -qq
        apt-get install -y -qq nfs-kernel-server > /dev/null 2>&1
    elif command -v dnf >/dev/null; then
        dnf install -y -q nfs-utils > /dev/null 2>&1
    elif command -v yum >/dev/null; then
        yum install -y -q nfs-utils > /dev/null 2>&1
    else
        die "Unsupported package manager. Install nfs-kernel-server or nfs-utils manually."
    fi
    success "NFS packages installed"

    # Create export directory
    mkdir -p "$NFS_PATH"
    chmod 777 "$NFS_PATH"

    # Add export (idempotent)
    local export_line="${NFS_PATH} *(rw,sync,no_subtree_check,no_root_squash)"
    if ! grep -qF "$NFS_PATH" /etc/exports 2>/dev/null; then
        echo "$export_line" >> /etc/exports
    fi

    exportfs -ra
    if command -v apt-get >/dev/null; then
        systemctl enable --now nfs-kernel-server
    else
        systemctl enable --now nfs-server
    fi
    success "NFS server running, exporting $NFS_PATH"
}

# =============================================================================
# Step 4: Install k0s
# =============================================================================
install_k0s() {
    header "Installing k0s Kubernetes"

    if command -v k0s &>/dev/null; then
        info "k0s already installed, skipping download"
    elif [[ "${AIRGAP:-false}" == "true" ]]; then
        local k0s_bin="${SCRIPT_DIR}/binaries/k0s"
        [[ -f "$k0s_bin" ]] || die "Air-gap mode: missing ${k0s_bin}. Build with: bash build.sh --airgap"
        info "Installing pre-staged k0s ${K0S_VERSION}..."
        cp "$k0s_bin" /usr/local/bin/k0s
        chmod +x /usr/local/bin/k0s
        success "k0s installed from local binary"
    else
        info "Downloading k0s ${K0S_VERSION}..."
        curl -sSLf "https://get.k0s.sh" | K0S_VERSION="${K0S_VERSION}" sh
        success "k0s downloaded"
    fi

    # Install as single-node controller+worker
    if k0s status &>/dev/null; then
        info "k0s already running, skipping install"
    else
        info "Installing k0s single-node cluster..."
        k0s install controller --single
        k0s start
        success "k0s cluster started"
    fi

    # Wait for k0s to be ready
    info "Waiting for k0s API server..."
    local retries=60
    while ! k0s kubectl get nodes &>/dev/null && (( retries-- > 0 )); do
        sleep 2
    done
    (( retries > 0 )) || die "k0s API server did not become ready"

    # Setup kubeconfig
    mkdir -p ~/.kube
    k0s kubeconfig admin > ~/.kube/config
    chmod 600 ~/.kube/config
    export KUBECONFIG=~/.kube/config

    # Wait for node to be Ready
    info "Waiting for node to be Ready..."
    retries=60
    while ! k0s kubectl get nodes | grep -q " Ready" && (( retries-- > 0 )); do
        sleep 5
    done
    (( retries > 0 )) || die "Node did not reach Ready state"

    success "k0s cluster ready"
    k0s kubectl get nodes

    # Set vm.max_map_count for Elasticsearch
    # Required by ES to handle memory-mapped files; without this the ES
    # pod needs a privileged init container which violates pod security policies.
    if [[ "$(sysctl -n vm.max_map_count 2>/dev/null)" != "262144" ]]; then
        info "Setting vm.max_map_count for Elasticsearch..."
        sysctl -w vm.max_map_count=262144 >/dev/null
        if ! grep -q "^vm.max_map_count=262144" /etc/sysctl.conf 2>/dev/null; then
            echo "vm.max_map_count=262144" >> /etc/sysctl.conf
        fi
        success "vm.max_map_count set to 262144"
    else
        success "vm.max_map_count already set to 262144"
    fi

    # Install local-path-provisioner as default StorageClass
    # k0s does not ship with a storage provisioner — PVCs need one to bind
    info "Installing local-path-provisioner (default StorageClass)..."
    if [[ "${AIRGAP:-false}" == "true" ]]; then
        local lpp_manifest="${SCRIPT_DIR}/binaries/local-path-storage.yaml"
        [[ -f "$lpp_manifest" ]] || die "Air-gap mode: missing ${lpp_manifest}. Build with: bash build.sh --airgap"
        k0s kubectl apply -f "$lpp_manifest"
    else
        k0s kubectl apply -f https://raw.githubusercontent.com/rancher/local-path-provisioner/v0.0.30/deploy/local-path-storage.yaml
    fi
    sleep 5
    k0s kubectl annotate storageclass local-path \
        storageclass.kubernetes.io/is-default-class=true --overwrite
    success "local-path StorageClass ready (default)"
}

# =============================================================================
# Step 5: Install Helm
# =============================================================================
install_helm() {
    header "Installing Helm"

    if command -v helm &>/dev/null; then
        info "Helm already installed: $(helm version --short)"
        return
    fi

    if [[ "${AIRGAP:-false}" == "true" ]]; then
        local helm_bin="${SCRIPT_DIR}/binaries/helm"
        [[ -f "$helm_bin" ]] || die "Air-gap mode: missing ${helm_bin}. Build with: bash build.sh --airgap"
        info "Installing pre-staged Helm ${HELM_VERSION}..."
        cp "$helm_bin" /usr/local/bin/helm
        chmod +x /usr/local/bin/helm
    else
        info "Downloading Helm ${HELM_VERSION}..."
        curl -sSL https://get.helm.sh/helm-${HELM_VERSION}-linux-amd64.tar.gz | tar xz -C /tmp
        mv /tmp/linux-amd64/helm /usr/local/bin/helm
        rm -rf /tmp/linux-amd64
        chmod +x /usr/local/bin/helm
    fi

    success "Helm installed: $(helm version --short)"
}

# =============================================================================
# Step 6: Generate TLS Certificates
# =============================================================================
generate_certificates() {
    header "Generating TLS Certificates"

    local cert_dir="${SCRIPT_DIR}/certs"
    mkdir -p "$cert_dir"

    # Generate CA (10 year)
    info "Creating Certificate Authority..."
    openssl req -x509 -nodes -newkey rsa:2048 \
        -keyout "${cert_dir}/ca.key" \
        -out "${cert_dir}/ca.pem" \
        -days 3650 \
        -subj "/CN=Kinetic Platform CA" \
        2>/dev/null

    # Generate leaf cert with wildcard SAN (10 year)
    info "Creating leaf certificate for ${DOMAIN}..."
    cat > "${cert_dir}/san.cnf" <<EOF
[req]
distinguished_name = req_dn
req_extensions = v3_req
prompt = no

[req_dn]
CN = ${DOMAIN}

[v3_req]
subjectAltName = DNS:${DOMAIN},DNS:*.${DOMAIN}
EOF

    openssl req -nodes -newkey rsa:2048 \
        -keyout "${cert_dir}/leaf.key" \
        -out "${cert_dir}/leaf.csr" \
        -config "${cert_dir}/san.cnf" \
        2>/dev/null

    openssl x509 -req \
        -in "${cert_dir}/leaf.csr" \
        -CA "${cert_dir}/ca.pem" \
        -CAkey "${cert_dir}/ca.key" \
        -CAcreateserial \
        -out "${cert_dir}/leaf.pem" \
        -days 3650 \
        -extensions v3_req \
        -extfile "${cert_dir}/san.cnf" \
        2>/dev/null

    TLS_CERT="${cert_dir}/leaf.pem"
    TLS_KEY="${cert_dir}/leaf.key"
    TLS_CHAIN="${cert_dir}/ca.pem"

    success "Certificates generated in ${cert_dir}/"
}

# =============================================================================
# Step 7: Seed Values File
# =============================================================================
seed_values() {
    header "Generating Values File"

    cp "$TPL_FILE" "$VALUES_FILE"

    # Simple replacements
    sed -i "s|__HOSTNAME__|${DOMAIN}|g" "$VALUES_FILE"
    sed -i "s|__NFS_SERVER__|${NFS_SERVER}|g" "$VALUES_FILE"
    sed -i "s|__NFS_PATH__|${NFS_PATH}|g" "$VALUES_FILE"
    sed -i "s|__SYSTEM_USERNAME__|${SYSTEM_USERNAME}|g" "$VALUES_FILE"
    sed -i "s|__SYSTEM_PASSWORD__|${SYSTEM_PASSWORD}|g" "$VALUES_FILE"
    sed -i "s|__ENCRYPTION_KEY__|${ENCRYPTION_KEY}|g" "$VALUES_FILE"
    sed -i "s|__TRUSTED_SECRET__|${TRUSTED_SECRET}|g" "$VALUES_FILE"
    sed -i "s|__ACTIVE_SECRET__|${ACTIVE_SECRET}|g" "$VALUES_FILE"
    sed -i "s|__INGRESS_PROVIDER__|${INGRESS_PROVIDER}|g" "$VALUES_FILE"
    sed -i "s|__INGRESS_CLASS__|${INGRESS_CLASS}|g" "$VALUES_FILE"
    sed -i "s|__INGRESS_NGINX_ENABLED__|${INGRESS_NGINX_ENABLED}|g" "$VALUES_FILE"
    sed -i "s|__TRAEFIK_ENABLED__|${TRAEFIK_ENABLED}|g" "$VALUES_FILE"
    sed -i "s|__ELASTICSEARCH_ENABLED__|${ELASTICSEARCH_ENABLED}|g" "$VALUES_FILE"
    sed -i "s|__ES_IN_CLUSTER__|${ES_IN_CLUSTER}|g" "$VALUES_FILE"
    sed -i "s|__ES_HOST__|${ES_HOST}|g" "$VALUES_FILE"
    sed -i "s|__ES_PORT__|${ES_PORT}|g" "$VALUES_FILE"
    sed -i "s|__ES_SCHEME__|${ES_SCHEME}|g" "$VALUES_FILE"
    sed -i "s|__ES_USERNAME__|${ES_USERNAME}|g" "$VALUES_FILE"
    sed -i "s|__ES_PASSWORD__|${ES_PASSWORD}|g" "$VALUES_FILE"
    sed -i "s|__USE_GENERATED_PASSWORD__|${USE_GENERATED_PASSWORD}|g" "$VALUES_FILE"
    sed -i "s|__ES_CERT__|${ES_CERT}|g" "$VALUES_FILE"
    sed -i "s|__LOGHUB_ENABLED__|${LOGHUB_ENABLED}|g" "$VALUES_FILE"
    sed -i "s|__LOG_COLLECTOR_ENABLED__|${LOG_COLLECTOR_ENABLED}|g" "$VALUES_FILE"
    sed -i "s|__CASSANDRA_TRUSTSTORE_PASSWORD__|${CASSANDRA_TRUSTSTORE_PASSWORD}|g" "$VALUES_FILE"

    # Port configuration
    sed -i "s|__HTTP_NODEPORT__|${HTTP_NODEPORT}|g" "$VALUES_FILE"
    sed -i "s|__HTTPS_NODEPORT__|${HTTPS_NODEPORT}|g" "$VALUES_FILE"

    # hostPort lines — insert indented YAML or remove the placeholder line
    if [[ "$USE_HOST_PORT" == "true" ]]; then
        # nginx hostPort (6-space indent under ports.http / ports.https)
        sed -i "s|__NGINX_HTTP_HOSTPORT__|      hostPort: 80|" "$VALUES_FILE"
        sed -i "s|__NGINX_HTTPS_HOSTPORT__|      hostPort: 443|" "$VALUES_FILE"
        # traefik hostPort (6-space indent under ports.web / ports.websecure)
        sed -i "s|__TRAEFIK_HTTP_HOSTPORT__|      hostPort: 80|" "$VALUES_FILE"
        sed -i "s|__TRAEFIK_HTTPS_HOSTPORT__|      hostPort: 443|" "$VALUES_FILE"
    else
        # Remove placeholder lines entirely
        sed -i "/__NGINX_HTTP_HOSTPORT__/d" "$VALUES_FILE"
        sed -i "/__NGINX_HTTPS_HOSTPORT__/d" "$VALUES_FILE"
        sed -i "/__TRAEFIK_HTTP_HOSTPORT__/d" "$VALUES_FILE"
        sed -i "/__TRAEFIK_HTTPS_HOSTPORT__/d" "$VALUES_FILE"
    fi

    # Multiline PEM replacements — indent each line with 8 spaces for YAML block scalar
    # The template has __TLS_CERT__, __TLS_KEY__, __TLS_CHAIN__ on their own lines
    local indent="        "

    replace_pem_block() {
        local placeholder="$1"
        local pem_file="$2"
        local indented
        indented=$(awk -v indent="$indent" '{print indent $0}' "$pem_file")
        # Use awk to replace the placeholder line with indented PEM content
        awk -v placeholder="$placeholder" -v replacement="$indented" '
            $0 ~ placeholder { print replacement; next }
            { print }
        ' "$VALUES_FILE" > "${VALUES_FILE}.tmp" && mv "${VALUES_FILE}.tmp" "$VALUES_FILE"
    }

    replace_pem_block "__TLS_CERT__" "$TLS_CERT"
    replace_pem_block "__TLS_KEY__" "$TLS_KEY"
    replace_pem_block "__TLS_CHAIN__" "$TLS_CHAIN"

    success "Values file generated: $VALUES_FILE"
}

# =============================================================================
# Step 8: Label CoreDNS ConfigMap
# =============================================================================
label_coredns() {
    header "Labeling CoreDNS for Helm"

    # k0s manages CoreDNS — we need Helm to own it
    local kubectl="k0s kubectl"

    # Wait for the configmap to exist
    info "Waiting for CoreDNS configmap..."
    local retries=30
    while ! $kubectl get configmap coredns -n kube-system &>/dev/null && (( retries-- > 0 )); do
        sleep 2
    done

    $kubectl label configmap coredns -n kube-system \
        app.kubernetes.io/managed-by=Helm --overwrite

    $kubectl annotate configmap coredns -n kube-system \
        meta.helm.sh/release-name="${RELEASE_NAME}" \
        meta.helm.sh/release-namespace="${NAMESPACE}" --overwrite

    success "CoreDNS configmap labeled for Helm ownership"
}

# =============================================================================
# Step 9: Install Platform
# =============================================================================
install_platform() {
    header "Installing Kinetic Platform"

    info "This may take 10-15 minutes on first install..."

    local kubectl="k0s kubectl"

    # Create namespace
    $kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml | $kubectl apply -f -

    # Install without --wait so we can orchestrate startup order ourselves
    helm upgrade --install "${RELEASE_NAME}" "$CHART_FILE" \
        -f "$VALUES_FILE" \
        -n "${NAMESPACE}" \
        --create-namespace \
        --timeout 15m \
        2>&1 | tail -5

    success "Helm chart deployed"
}

# =============================================================================
# Step 10: Staged Startup
# =============================================================================
staged_startup() {
    header "Orchestrating Startup Order"

    local kubectl="k0s kubectl"

    # Deployments that depend on Cassandra + init jobs completing
    local CASSANDRA_DEPENDENTS="core agent indexer cassandra-browser"

    # --- Phase 1: Scale down Cassandra-dependent deployments ---
    info "Scaling down Cassandra-dependent services..."
    for dep in $CASSANDRA_DEPENDENTS; do
        local deploy_name
        deploy_name=$($kubectl get deploy -n "${NAMESPACE}" --no-headers -o custom-columns=':metadata.name' 2>/dev/null \
            | grep -E "^${dep}$|^${dep}-" | head -1)
        if [[ -n "$deploy_name" ]]; then
            $kubectl scale deploy "$deploy_name" -n "${NAMESPACE}" --replicas=0 2>/dev/null || true
        fi
    done
    success "Cassandra-dependent services scaled to 0"

    # --- Phase 2: Wait for Cassandra to be ready ---
    info "Waiting for Cassandra to be ready..."
    local retries=120
    while ! $kubectl get pods -n "${NAMESPACE}" -l app.kubernetes.io/name=cassandra \
        --no-headers 2>/dev/null | grep -q 'Running' && (( retries-- > 0 )); do
        sleep 5
        printf "\r  Cassandra: waiting... (%d) " "$retries"
    done
    echo ""
    if (( retries <= 0 )); then
        warn "Cassandra may not be fully ready — continuing anyway"
    else
        success "Cassandra is running"
    fi

    # --- Phase 3: Wait for init jobs (in parallel) ---
    info "Waiting for init jobs to complete..."

    wait_for_job() {
        local job_name="$1"
        local retries=60
        while ! $kubectl get job "$job_name" -n "${NAMESPACE}" -o jsonpath='{.status.succeeded}' \
            2>/dev/null | grep -q '1' && (( retries-- > 0 )); do
            sleep 5
        done
        if (( retries <= 0 )); then
            warn "$job_name may not have completed"
            return 1
        else
            success "$job_name complete"
            return 0
        fi
    }

    wait_for_job platform-certificate-init &
    local pid_cert=$!
    wait_for_job cassandra-adapter-secret-init &
    local pid_cass=$!
    wait_for_job cassandra-metadata &
    local pid_meta=$!

    wait "$pid_cert" || true
    wait "$pid_cass" || true
    wait "$pid_meta" || true

    # --- Phase 4: Scale up Cassandra-dependent deployments ---
    info "Scaling up Cassandra-dependent services..."
    for dep in $CASSANDRA_DEPENDENTS; do
        local deploy_name
        deploy_name=$($kubectl get deploy -n "${NAMESPACE}" --no-headers -o custom-columns=':metadata.name' 2>/dev/null \
            | grep -E "^${dep}$|^${dep}-" | head -1)
        if [[ -n "$deploy_name" ]]; then
            $kubectl scale deploy "$deploy_name" -n "${NAMESPACE}" --replicas=1 2>/dev/null || true
        fi
    done
    success "Cassandra-dependent services scaled to 1"

    # --- Phase 5: Clean up completed/failed job pods ---
    # Jobs with retries leave behind Error/Init:Error pods that block
    # wait_and_verify's pod readiness count.
    info "Cleaning up finished init job pods..."
    for job in platform-certificate-init cassandra-adapter-secret-init cassandra-metadata db-adapter-secret-init; do
        $kubectl delete job "$job" -n "${NAMESPACE}" --ignore-not-found 2>/dev/null || true
    done
    success "Init job pods cleaned up"
}

# =============================================================================
# Step 11: Wait and Verify
# =============================================================================
wait_and_verify() {
    header "Verifying Deployment"

    local kubectl="k0s kubectl"

    info "Waiting for all pods to reach Running/Completed state..."
    local retries=90
    local not_ready=1
    while (( not_ready > 0 && retries-- > 0 )); do
        sleep 10
        not_ready=$($kubectl get pods -n "${NAMESPACE}" --no-headers 2>/dev/null \
            | { grep -v -E 'Running|Completed|Error' || true; } \
            | wc -l)
        local total=$($kubectl get pods -n "${NAMESPACE}" --no-headers 2>/dev/null \
            | { grep -v -E 'Error' || true; } \
            | wc -l)
        local ready=$(( total - not_ready ))
        printf "\r  Pods: %d/%d ready " "$ready" "$total"
    done
    echo ""

    if (( not_ready > 0 )); then
        warn "Some pods are not ready:"
        $kubectl get pods -n "${NAMESPACE}" | { grep -v -E 'Running|Completed|Error' || true; }
    else
        success "All pods are ready"
    fi

    # Print pod summary
    echo ""
    $kubectl get pods -n "${NAMESPACE}" --sort-by=.metadata.name

    # Print credentials and summary
    header "Installation Complete"

    echo ""
    echo -e "${BOLD}${GREEN}========================================${NC}"
    echo -e "${BOLD}${GREEN}         Platform Credentials           ${NC}"
    echo -e "${BOLD}${GREEN}========================================${NC}"
    echo -e "${BOLD}  URL:       ${NC} https://${DOMAIN}/app/console/"
    echo -e "${BOLD}  Username:  ${NC} ${SYSTEM_USERNAME}"
    echo -e "${BOLD}  Password:  ${NC} ${SYSTEM_PASSWORD}"
    echo -e "${BOLD}${GREEN}========================================${NC}"
    echo ""
    echo -e "${BOLD}Ingress Provider:${NC}  ${INGRESS_PROVIDER}"
    if [[ "$USE_HOST_PORT" == "true" ]]; then
        echo -e "${BOLD}Ports:${NC}             80/443 (hostPort)"
    else
        echo -e "${BOLD}Ports:${NC}             30080/30443 (NodePort)"
    fi
    echo -e "${BOLD}NFS Server:${NC}        ${NFS_SERVER}"
    echo -e "${BOLD}NFS Path:${NC}          ${NFS_PATH}"
    if [[ -n "$PUBLIC_IP" ]]; then
        echo -e "${BOLD}Public IP:${NC}         ${PUBLIC_IP}"
    fi
    echo ""
    echo -e "${BOLD}Values File:${NC}       ${VALUES_FILE}"
    echo -e "${BOLD}Certificates:${NC}      ${SCRIPT_DIR}/certs/"
    echo ""
    local DNS_IP="${PUBLIC_IP:-$NFS_SERVER}"
    echo -e "${YELLOW}Next Steps:${NC}"
    if [[ "$USE_HOST_PORT" == "true" ]]; then
        echo "  1. Point DNS for ${DOMAIN} to ${DNS_IP} (or add to /etc/hosts)"
        echo "  2. Open https://${DOMAIN}/app/console/ in your browser"
    else
        echo "  1. On your local machine, run: ./local-access.sh"
        echo "  2. Enter server IP: ${DNS_IP}"
        echo "  3. Enter domain: ${DOMAIN}"
        echo "  4. Open https://${DOMAIN}/app/console/ in your browser"
    fi
    echo ""
    echo "  Credentials are also stored in: ${VALUES_FILE}"

    # License notice
    echo ""
    echo -e "${CYAN}  ════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${BOLD}    Kinetic Platform — Community Edition${NC}"
    echo ""
    echo -e "${CYAN}  ════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "    Copyright (c) 2026 Kinetic Data, Inc. All rights reserved."
    echo ""
    echo "    This software is the proprietary property of Kinetic Data, Inc."
    echo "    and is provided under the following terms:"
    echo ""
    echo -e "${BOLD}    PERMITTED USE${NC}"
    echo "    This installation is licensed for personal, non-commercial use"
    echo "    including learning, evaluation, experimentation, and proof of"
    echo "    concept development. You may freely explore the platform to"
    echo "    assess its capabilities for your organization."
    echo ""
    echo -e "${BOLD}    RESTRICTIONS${NC}"
    echo "    - This software may not be used in production environments"
    echo "    - Redistribution or resale is prohibited"
    echo "    - Reverse engineering or modification of platform binaries"
    echo "      is prohibited"
    echo ""
    echo -e "${BOLD}    NO WARRANTY / NO SUPPORT${NC}"
    echo "    This software is provided \"AS IS\" without warranty of any kind,"
    echo "    express or implied. Kinetic Data does not provide technical"
    echo "    support, maintenance, or updates for community installations."
    echo "    Use at your own risk."
    echo ""
    echo -e "${BOLD}    READY FOR MORE?${NC}"
    echo "    When you're ready for production licensing, dedicated support,"
    echo "    and enterprise features, contact us:"
    echo ""
    echo "      https://www.kineticdata.com"
    echo "      sales@kineticdata.com"
    echo ""
    echo "    Thank you for trying Kinetic Platform."
    echo ""
    echo -e "${CYAN}  ════════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# =============================================================================
# Main
# =============================================================================
main() {
    echo -e "${BOLD}${CYAN}"
    echo "  ╔════════════════════════════════════════╗"
    echo "  ║     Kinetic Platform Installer v2      ║"
    echo "  ╚════════════════════════════════════════╝"
    echo -e "${NC}"

    validate_prerequisites
    if [[ "$DEMO_MODE" == "true" ]]; then
        demo_defaults
    else
        prompt_user
    fi
    install_nfs
    install_k0s
    install_helm
    generate_certificates
    seed_values
    label_coredns
    install_platform
    staged_startup
    wait_and_verify
}

main "$@"
